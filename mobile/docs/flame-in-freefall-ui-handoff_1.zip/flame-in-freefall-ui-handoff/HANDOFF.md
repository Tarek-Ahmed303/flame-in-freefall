# Flame in Freefall — Astronaut Emergency App · Build Handoff

Build a native mobile app that matches the UI in `design/` pixel-for-pixel.
NASA Space Apps 2026 project. The app is **mobile-only** and shares the same backend + AI as the team's web dashboard. Its focus: **receive the fire alert, execute extinguishing steps fast, and talk to the AI by voice under pressure.** It must NOT duplicate the web's "Explore Data" or "Report Generator".

**Target framework:** `<<FILL IN: Flutter | Kotlin + Jetpack Compose>>`

## What's in this folder

| Path | Use |
|---|---|
| `design/screenshots/*.png` | Visual source of truth (390×844 @2x). Match these. |
| `design/preview/*.html` | Open in a browser — live, animated version of each screen. Links between screens work. |
| `design/source/*.dc.html` | Exact markup: every color, size, radius, spacing, font and animation is in the inline styles. Read values from here — never guess. |

Design frame = 390×844 logical px (iPhone 14 size). Treat 1 CSS px = 1 dp/logical px. No fake status bar is drawn — respect the real safe areas.

## Screens & navigation

| # | File | Screen | Navigates to |
|---|---|---|---|
| 01 | Main | Splash (mini-game) | Log in ("Tap to continue", or auto after loading) |
| 02 | Login | Log in | Home · Sign up |
| 03 | SignUp | Sign up | Home · Log in |
| 04 | Home | Home | Chat · HomeAlert (Simulate Emergency) · Guide · Settings |
| 05 | Chat | AI Assistant — normal mode | Home |
| 06 | HomeAlert | In-app critical alert (app in foreground) | ChatEmergency |
| 07 | Alert | Push notification on lock screen (app in background) | ChatEmergency |
| 08 | ChatEmergency | AI Assistant — emergency mode | Home |
| 09 | SafetyGuide | Safety Guide | bottom nav |
| 10 | Settings | Settings | Log in (Sign out) · bottom nav |

Bottom nav (Home · AI · Guide · Settings) on 04, 09, 10. Chat screens are full-focus (back button, no nav).

**05 and 08 are ONE screen with two modes** (`normal` / `emergency`). Emergency mode adds the red banner + timer, the AI warning card, the step cards and an always-on mic dock; after the last step it shows "Protocol complete" and returns to normal mode.

## Design tokens

Colors
```
bg            #02040A (splash/auth)  #04060B (app)  #06050A (emergency)
surface       #0B1018   surface-2 #0F1520   surface-3 #111826   #161C27
stroke        rgba(150,180,220,.12–.22)
text          #E8EEF6   text-2 #B7C2D2   muted #8B98AB   faint #6F7C90
brand/orange  #FF7A2F   (on-orange text #1A0800)  light #FF9A5C
cyan (focus)  #5BC8F5
danger/red    #FF4538   red-text #FF8A7F / #FF7B6E
success       #3DDC97   warning #FFC042
```
Fonts (Google Fonts): **Chakra Petch** 500/600/700 (display, buttons, numbers) · **IBM Plex Sans** 400/500/600 (body) · **IBM Plex Mono** 400/500 (labels, telemetry, all-caps tags with letter-spacing .1–.2em) · IBM Plex Sans Arabic (Arabic option).

Shape: cards 14–20 radius · auth inputs 3 radius with corner-bracket "HUD" marks · primary CTA has chamfered corners (14px cut, top-left + bottom-right) · pills 12–28 radius. Min touch target 44.

Icons: simple 24×24 stroke icons (1.8 stroke, round caps). Paths are inline in the source — reuse them as vector assets.

## Signature components (reuse)

- **Starfield background**: two drifting star layers (90s / 45s loops) + twinkle. Used on Splash, Login, Sign up, lock-screen Alert.
- **Channel input** (Login/Sign up): mono label `CH-01 · CREW EMAIL`, 52–56 tall box, 4 corner brackets; focused state = cyan border + glow + a light band scanning left→right (3s loop) + tick ruler under the field.
- **Chamfered CTA** (orange) · **Hazard-stripe header** (−45° red stripes) on emergency UI.
- **Risk gauge**: 200° arc, value 0–100, color by level (LOW green / MED amber / HIGH red).
- **Step card** states: done (green check, strikethrough) · current (orange border, "MARK DONE" + read-aloud) · upcoming (dim).
- **Voice dock**: text field row + animated waveform + 64px orange mic with pulsing ring.

## Behaviour

**Splash mini-game (01)** — canvas game in the top 500px. 6×4 grid of cartoon chickens sway and drop fireballs; the player ship auto-fires coolant shots. Ship plays itself (tracks nearest chicken, dodges fireballs) until the user drags, then follows the finger for 2.5s. Hit = feather burst + score +100; new wave 1.2s after clearing. Full logic is in `design/source/Main.dc.html` (`step()`/`draw()`), port it 1:1 (Flutter: CustomPainter + Ticker; Compose: Canvas + withFrameNanos). Below: title, loading bar, status lines (backend link / AI core / telemetry) — wire these to real health checks, then go to Log in.

**Simulate Emergency (Home, DEMO)** — calls the SAME endpoint the backend uses for a real detection, with fixed mock values. Then:
1. Vibration (SOS pattern) + alarm sound.
2. Local/push notification, **critical / high-priority** (Android: full-screen intent + alarm channel; iOS: time-sensitive/critical if entitled) — must show even when app is backgrounded (screen 07).
3. If app is in foreground → in-app banner overlay (screen 06) with "OPEN AI STEPS" + "Silence".
4. Tapping notification/banner → ChatEmergency (08) with auto messages: AI warning "Fire detected — PMMA material, oxygen 19%, high risk" + telemetry chips, then step 1 card.
5. User can still ask by voice or text — chat works normally alongside the alert.
6. Banner timer counts up from detection time.

Mock scenario: material PMMA · module Destiny Lab · rack LAB1O3 · O₂ 19.0% · CO 38 ppm rising · airflow 0.08 m/s · risk HIGH.
Steps: 1 Cut power & airflow · 2 Put on breathing mask · 3 Discharge CO₂ extinguisher · 4 Verify & report (full text in ChatEmergency source).

**Voice** — speech-to-text for questions (hold mic on 05, always-listening dock on 08), text-to-speech for AI replies and each step ("Read aloud"). Wake phrase "Hey Flame" toggle in Settings. Language EN / AR for both STT and TTS.

**Chat (05)** — real chat against the shared backend AI. AI answers can come back as structured cards (risk level tag, condition rows, source chips, actions "Read aloud" / "Save to guide"). Suggested-question chips above the composer.

**Home (04)** — fire-risk index + O₂ / pressure / airflow / watched material + 6h trend, from the same model the web uses (simplified view). Refresh live (poll or socket).

**Safety Guide (09)** — read-only quick reference, cached for offline: fire steps, material risk bars, O₂ threshold scale (<19.5 low · 19.5–23.5 nominal · >23.5 fire risk rises). Synced from the latest web report.

**Settings (10)** — profile (name, role, crew ID, module, shift), voice (read aloud, wake phrase, assistant voice, speech rate), language EN/AR (RTL support), alerts (critical override, vibration pattern, alarm volume), sign out.

## Animations — ALL must be implemented in the app

Every moving element in `design/preview/*.html` is part of the spec, not decoration to skip. Exact keyframes are in each source file's `<style>` block; timings below.

| Screen | Element | Animation |
|---|---|---|
| Splash, Login, Sign up, Lock-screen alert | Starfield | 2 star layers drift down 300px in a seamless loop (90s and 45s, linear); 2nd layer twinkles opacity 1→.45, 4s ease-in-out. Home uses the 90s layer at 55% opacity (120s). |
| Splash | Mini-game | 60fps canvas game (see Behaviour). |
| Splash | Title block | Fade + rise in: opacity 0→1, translateY 14→0, 1.2s ease-out, once. |
| Splash | Loading bar | Width 3%→100% over 3.4s ease-in-out, loops (or drive from real loading progress). |
| Splash | "SYNCING" | Blink 1.2s, steps(2). |
| Login / Sign up | Focused input | Light band scans left→right across the field, 3s linear loop; cyan glow border. |
| Login | "SIGNAL LOCK" dot | Opacity blink 1→.3, 1.6s. |
| Login / Sign up | Orbit ring + station / satellite | Dashed ring rotates 360°, 120s (Login) / 80s (Sign up), linear. |
| Home | "BACKEND LIVE" dot | Blink 1.6s. |
| Home, Chat | Mic button ring | Ring scales .7→1.6 while fading out, 2.2s ease-out loop. |
| In-app alert (06) | Screen edges | Red inner glow pulses, 1.1s ease-in-out loop. |
| In-app alert (06) | Banner | Drops in from −30px + fade, 0.5s cubic-bezier(.2,.9,.3,1.2). |
| In-app alert (06), Lock screen (07) | Vibration icon | Shake ±2–3px, 0.4–0.5s loop (sync with real vibration). |
| Lock screen (07) | Red ambient light | Opacity .25→.85, 1.1s loop. |
| Lock screen (07) | Notification card | Drop in 0.6s, same overshoot curve. |
| Lock screen (07) | Ripple rings | 2 rings scale .7→1.7 + fade, 1.4s, 2nd delayed 0.7s. |
| Emergency chat (08) | Top red glow | Opacity .35→1, 1.2s loop. |
| Emergency chat (08) | Status dot | Blink 0.8s. |
| Emergency chat (08) | Elapsed timer | Counts up every second (mm:ss). |
| Emergency chat (08) | Voice waveform | 12 bars, scaleY .25→1, 0.9s ease-in-out, staggered delays 0–0.45s; drive from real mic amplitude when listening. |
| Emergency chat (08) | Mic ring | Same as Home but 1.6s. |
| Emergency chat (08) | Step cards | On "MARK DONE": current card collapses to done row, next expands (add ~250ms expand/collapse + progress segment fill). |

Respect the OS "reduce motion" setting: keep alerts/timers, turn the looping decorative animations off.

## Backend contract (fill in with the backend teammate)

All values in the designs are **mock data** — replace with API data.
```
POST /auth/login           POST /auth/register
GET  /risk/current         -> { index, level, o2, pressure, airflow, watchMaterial, trend[] }
POST /chat                 -> { text, cards?[] }   (same AI as web)
POST /alerts/trigger       -> real detection AND Simulate Emergency (mock payload)
GET  /alerts/{id}/steps    -> [{ title, body }]
GET  /guide                -> quick-reference content
Push: FCM (Android) / APNs (iOS) for alerts
```
`<<CONFIRM real base URL, endpoint names and payloads>>`

## Build order
1. Theme/tokens + fonts + shared components (starfield, channel input, CTA, cards, bottom nav).
2. Static screens 02–10 matching screenshots, with navigation.
3. Chat with backend + structured cards; voice (STT/TTS).
4. Simulate Emergency flow end-to-end (vibration, sound, notification, in-app banner, emergency mode).
5. Splash mini-game.
6. Live risk data, offline guide cache, Arabic/RTL.
